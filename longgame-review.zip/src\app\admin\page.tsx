﻿import Link from "next/link";

export default function AdminPage() {
  return (
    <div>
      <h1 className="font-heading text-3xl font-bold mb-8">Admin Dashboard</h1>
      <div className="grid md:grid-cols-2 gap-4">
        <Link
          href="/admin/organizations"
          className="bg-cream/60 border border-border-grey rounded-2xl p-6 hover:border-gold transition-colors shadow-[0_4px_16px_rgba(18,21,20,0.08)] hover:shadow-[0_8px_24px_rgba(18,21,20,0.12)]"
        >
          <h3 className="font-heading font-semibold mb-1">Organizations</h3>
          <p className="font-body text-sm text-text-muted">
            Manage orgs, codes, and approvals
          </p>
        </Link>
        <Link
          href="/admin/users"
          className="bg-cream/60 border border-border-grey rounded-2xl p-6 hover:border-gold transition-colors shadow-[0_4px_16px_rgba(18,21,20,0.08)] hover:shadow-[0_8px_24px_rgba(18,21,20,0.12)]"
        >
          <h3 className="font-heading font-semibold mb-1">Users</h3>
          <p className="font-body text-sm text-text-muted">
            Search users, grant or revoke access
          </p>
        </Link>
        <Link
          href="/admin/content"
          className="bg-cream/60 border border-border-grey rounded-2xl p-6 hover:border-gold transition-colors shadow-[0_4px_16px_rgba(18,21,20,0.08)] hover:shadow-[0_8px_24px_rgba(18,21,20,0.12)]"
        >
          <h3 className="font-heading font-semibold mb-1">Content</h3>
          <p className="font-body text-sm text-text-muted">
            Manage modules, field guides, and tools
          </p>
        </Link>
        <Link
          href="/admin/leads"
          className="bg-cream/60 border border-border-grey rounded-2xl p-6 hover:border-gold transition-colors shadow-[0_4px_16px_rgba(18,21,20,0.08)] hover:shadow-[0_8px_24px_rgba(18,21,20,0.12)]"
        >
          <h3 className="font-heading font-semibold mb-1">Leads</h3>
          <p className="font-body text-sm text-text-muted">
            View and export Free Guide leads
          </p>
        </Link>
      </div>
    </div>
  );
}


